/* 
 * Adiba Mohammed 
 * Homework 11 - Serialization
 * 11/17/2021
 * This program uses serialization to create a menu driven program.
 */


package homework11;

import java.util.*;
import java.io.*;

public class Person implements Serializable {
	private static int count = 0;	
	  private int choice;		
	  private String name;		
	  private String phoneNum;	          
	  private String dob;		
	  private String email;		
	  
	  public Person (String name, String phoneNumber, String dob, String email) {
	    this.choice = count + 1;
	    this.name = name;
	    this.phoneNum = phoneNumber;
	    this.dob = dob;
	    this.email = email;
	    count++; }	
	  
	  public int getChoice () {
	    return choice; }			
	  
	  public String getName () {
	    return name; }
	  
	  public String getPhone_Number () {
	    return phoneNum; }
	  
	  public String getDob () {
	    return dob; }
	  
	  public String getEmail () {
	    return email; }

	  public void setName (String name) {
	    this.name = name; }
	  
	  public void setPhone_Number (String phoneNumber) {
	    this.phoneNum = phoneNumber; }
	  
	  public void setDob (String dob) {
	    this.dob = dob; }
	  
	  public void setEmail (String email) {
	    this.email = email; }
	  
	  public String toString () {
	    return "Name: " + name + ", Phone Number : " + phoneNum + ", Date of Birth: " 
	  + dob + ", email: " + email; }
	  
	}




