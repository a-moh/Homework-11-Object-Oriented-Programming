/* 
 * Adiba Mohammed 
 * Homework 11 - Serialization
 * 11/17/2021
 * This program uses serialization to create a menu driven program.
 */


package homework11;

import java.io.FileInputStream; 
import java.io.FileOutputStream;
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream;
import java.util.ArrayList; 
import java.util.Scanner;

public class Main {
	private static ArrayList < Person > personsinfo = new ArrayList < Person > ();
	private static Scanner reader = new Scanner (System.in);
	private static String fileName = "People.txt";

 public static void addInformation () {
	      int choice;			
          String fullName;		
		  String Phone_Number;		
		  String dob;			
		  String email;		

	 System.out.print ("Full Name: ");
	 fullName = reader.nextLine ();

     System.out.print ("Phone Number: ");
     Phone_Number = reader.nextLine ();

     System.out.print ("Date of Birth: ");
     dob = reader.nextLine ();

     System.out.print ("E-mail address: ");
     email = reader.nextLine ();

   Person p1 = new Person (fullName, Phone_Number, dob, email);
   personsinfo.add (p1);		
   
   try {
   	FileOutputStream filestream = new FileOutputStream (fileName);
   	ObjectOutputStream objectstream = new ObjectOutputStream (filestream);
       objectstream.writeObject (personsinfo);
       objectstream.close ();
       filestream.close (); }
   
   catch (Exception e) {
     System.out.println ("There was an Error!! " + e); }
   }				
 
 public static void display () {
	  try {
		  FileInputStream fileinputstream = new FileInputStream (fileName);
		  ObjectInputStream objectinputstream = new ObjectInputStream (fileinputstream);
		  ArrayList < Person > persons = (ArrayList < Person >) objectinputstream.readObject ();
		  objectinputstream.close ();
		  fileinputstream.close ();
		  
		  System.out.printf ("%5s %15s %24s %15s %20s\n", "Choice", "Name", "Phone Number", 
				  "DOB", "E-mail");  
		  int i = 0;
		  for (Person p2:persons){
			  System.out.printf ("%3d %23s %19s %15s %25s\n", p2.getChoice (),
					  p2.getName (), p2.getPhone_Number (), p2.getDob (), p2.getEmail ()); 
			  i++; }
		  }
	  
	  catch (Exception e) {
     System.out.println ("There was an Error!! " + e); }
	  }
 
 public static void deleteInformation () {
	  display ();
	  System.out.print ("Which number do you want to delete: ");
	  int choice = reader.nextInt ();
	  reader.nextLine ();
	  
	  int index = 1;
	  for (index = 1; index < personsinfo.size (); index++) {
		  if (personsinfo.get (index).getChoice () == choice) {
			  personsinfo.remove (index);
			  break; }
		  } 
	  
	  if (index == personsinfo.size ()) {
	System.out.println (choice + " doesn't exist");
	return; }
	  System.out.println (choice + " was deleted");
	  
	  try {
		  FileOutputStream filestream = new FileOutputStream (fileName);
		  ObjectOutputStream objectstream = new ObjectOutputStream (filestream);
		  objectstream.writeObject (personsinfo);
		  objectstream.close ();
		  filestream.close (); }
	  
	  catch (Exception e) {
     System.out.println ("There was an Error!!" + e); }
	  
	  try {
    int i = 1; 
	  
   for (Person p:personsinfo) {
	  System.out.printf ("%5d %20s %15s %10s %20s \n", p.getChoice (), p.getName (),
			  p.getPhone_Number (), p.getDob (), p.getEmail ());
	  i++; }
   }
	  
	  catch (Exception e) {
     System.out.println ("There was an Error!!" + e); }
	  }			
 
 public static void updateInformation () {
	 display ();
	 System.out.print ("Which number do you want to update information on: ");
	 int choice = reader.nextInt ();
	 reader.nextLine ();
	    
	 int index = 0;
	 for (index = 0; index < personsinfo.size (); index++) {
	 if (personsinfo.get (index).getChoice() == choice) {
		    System.out.print ("updated Full Name: ");
		    String name = reader.nextLine ();
		    personsinfo.get (index).setName (name);

		    System.out.print ("updated Phone Number: ");
		    String Phone_Number = reader.nextLine ();
		    personsinfo.get (index).setPhone_Number (Phone_Number);

		    System.out.print ("updated Date of Birth: ");
		    String dob = reader.nextLine ();
		    personsinfo.get (index).setDob (dob);

		    System.out.print ("updated e-mail address: ");
		    String email = reader.nextLine ();
		    personsinfo.get (index).setEmail (email);
		    break; }
		}
	    
	    if (index == personsinfo.size ()) {
		System.out.println (choice + " does not exist");
		return; }
	    System.out.println (choice + " update completed");
	    
	    try {
	    	FileOutputStream filestream = new FileOutputStream (fileName);
	    	ObjectOutputStream objectstream = new ObjectOutputStream (filestream);
	    	objectstream.writeObject (personsinfo);
	    	objectstream.close ();
	    	filestream.close (); }
	    
	    catch (Exception e) {
	      System.out.println ("There was an Error!!" + e); }
	    
	    try {
	      System.out.println ("file information after updating - ");
	      System.out.printf ("%5s %15s %24s %15s %20s\n", "Choice", "Name",
				 "Phone Number", "DOB", "E mail");
	      int i = 0;
	      
	      for (Person p:personsinfo) {
		  System.out.printf ("%3d %21s %19s %15s %25s\n", p.getChoice (),
				     p.getName (), p.getPhone_Number (), p.getDob (), p.getEmail ()); 
		  i++; }
	      }
	    
	    catch (Exception e) {
	      System.out.println ("There was an Error!!" + e); } 
	    }
	  
	  public static void main (String[]args) {
	    char ch;
	    
	    do {
		System.out.println ("\nMENU\n");
		System.out.println ("1) Add Information into a file");
		System.out.println ("2) Retrieve Information from a file and display");
		System.out.println ("3) Delete Information");
		System.out.println ("4) Update Information");
		System.out.println ("5) Exit");
		System.out.print ("Please enter your choice from 1-5:  ");
		ch = reader.next ().charAt (0);
		reader.nextLine ();	
		
		switch (ch) {
		  case '1':
		    addInformation ();
		    break;
		    
		  case '2':
		    display ();
		    break;
		    
		  case '3':
		    deleteInformation ();
		    break;

		  case '4':
		    updateInformation ();
		    break;

		  case '5':
		    System.out.println ("Menu Exited");
		    break;

		  default:
		    System.out.println ("Please choose an option from 1-5 ");
		    break; }
		}
	    
	    while (ch != '5'); }





 }
